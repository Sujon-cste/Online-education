-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 06, 2015 at 04:51 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cv`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(99) NOT NULL,
  `admin_email` varchar(256) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `admin_status` int(2) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_status`) VALUES
(1, 'Backlog Sujon', 'www.rateralo@gmail.com', '586fffc63ee816019283bb0ed3136262', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `blog_id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `category_id` int(3) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `published_time` datetime NOT NULL,
  PRIMARY KEY (`blog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `user_id`, `category_id`, `title`, `description`, `status`, `published_time`) VALUES
(9, 46, 0, 'About me', '<p>\r\n my name is Risat</p>\r\n', '1', '2014-05-08 17:05:41'),
(15, 46, 0, 'about php', '<p>\r\n there is huge opportunity in php.but there is also many candidate in this language.so it must be need to know this language very well</p>\r\n', '1', '2014-05-21 05:05:44');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(5) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `description`) VALUES
(3, 'java', 'its a boring programming language'),
(4, 'c++', 'it is my fouvarite language'),
(5, 'telecommunication', 'there is no need to add this subject with cse'),
(6, 'php', 'I think this is better than all of language');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `comments_id` int(5) NOT NULL AUTO_INCREMENT,
  `blog_id` int(26) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`comments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `my_cv`
--

CREATE TABLE IF NOT EXISTS `my_cv` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `last_name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `city` varchar(10) CHARACTER SET utf8 NOT NULL,
  `gender` varchar(6) NOT NULL,
  `country` varchar(10) CHARACTER SET utf8 NOT NULL,
  `mobile` varchar(15) CHARACTER SET utf8 NOT NULL,
  `zip_code` int(11) NOT NULL,
  `joining_date` datetime NOT NULL,
  `activation_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'if status=1 user active or not',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `my_cv`
--

INSERT INTO `my_cv` (`user_id`, `first_name`, `last_name`, `email`, `password`, `address`, `city`, `gender`, `country`, `mobile`, `zip_code`, `joining_date`, `activation_status`) VALUES
(46, 'risat', 'saha', 'saha@gmail.com', '3e8d3ff94015e3db10c9cf45aada9d65', '                                                                    samner block                                                                        ', 'noakhali', 'male', 'India', '0167864589', 1200, '0000-00-00 00:00:00', 1),
(55, 'Backlog', 'Sujon', 'rateralo@gmail.com', '730056bfa3536c8c6f7e70e896963d61', 'ASH', 'Dinajpur', 'male', 'Bangladesh', '01822447078', 5200, '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `upload_file`
--

CREATE TABLE IF NOT EXISTS `upload_file` (
  `file_id` int(3) NOT NULL AUTO_INCREMENT,
  `user_id` int(3) NOT NULL,
  `title` varchar(15) NOT NULL,
  `course` varchar(10) NOT NULL,
  `category` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `file_upload` varchar(256) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=113 ;

--
-- Dumping data for table `upload_file`
--

INSERT INTO `upload_file` (`file_id`, `user_id`, `title`, `course`, `category`, `type`, `file_upload`, `file_name`) VALUES
(111, 46, 'boi', 'CSTE-1101', 'lecture', 'pdf', 'images/file_upload/Boishakh_er_hahakar.pdf', 'Boishakh_er_hahakar.pdf'),
(112, 46, 'ddd', 'Select Cou', 'lecture', 'pdf', '0', '');
