<?php
class education_model extends CI_Model
{
               public function save_file($data){
        
        $this->db->insert('upload_file',$data);
    }
}


?>
