<?php

class Admin_Model extends CI_Model {
    //put your code here
    public function __construct() {
        parent::__construct();
    }
    public function admin_login_model($email,$password)
    {
       //$this->db->insert('admin',$data);
            $this->db->select('*');
        $this->db->from('admin');
        $this->db->where('admin_email',$email);
        $this->db->where('admin_password',md5($password));
        $query_r=$this->db->get();
        $result=$query_r->row();
        return $result;
    }
    public function save_cat_info($data)
    {
        $this->db->insert('category',$data);
        
    }
    public function get_category()
    {
        $this->db->select('*');
        $this->db->from('category');
        $mysql=$this->db->get();
        $result=$mysql->result();
        return $result;
    }
}

?>
