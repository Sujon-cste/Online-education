<?php
session_start();
class Admin extends CI_Controller{
    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->model('admin_model');

                  
   
        
    }
    public function index_login(){
        $this->load->view('admin_panel/admin_login');
    }
    public function admin_login()
    {
        
        $email=$this->input->post('login');
         $password=$this->input->post('pass');
         $result=  $this->admin_model->admin_login_model($email,$password);
    if(!$result)
    {
        echo "invalid user name or password";
         $this->load->view('admin_panel/admin_login');
    }
 else {
    $data=array();
    $data['name']=$result->admin_name;
    $data['admin_id']=$result->admin_id;
    $data['admin_status']=$result->admin_status;
    $this->session->set_userdata($data);
    $this->load->view('admin_panel/admin_home');
    }
    }
    public function logout()            {
 
        $this->session->unset_userdata('admin_id');
        session_destroy();
        redirect('admin/index_login');
    }
    public function add_category()
    {
        $data=array();
        $data['maincontent']=$this->load->view('admin_panel/category','',true);
        $this->load->view('admin_panel/admin_home',$data);
       
        
    }
    public function  save_category()
    {
        $data=array();
        $data['category_name']=$this->input->post('category_name',true);
        $data['description']=$this->input->post('description',true);
        $this->admin_model->save_cat_info($data);
        redirect("admin/add_category");
    }
   
}


?>
