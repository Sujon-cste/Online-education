<?php


session_start();
class Blogger extends CI_Controller{
public function __construct() {
    
    
            parent::__construct();
            $this->load->helper('download');
            $this->load->model('user_profile');
            $this->load->model('blogger_model');
            $this->load->model('admin_model');
            $this->load->model('education_model');
            
              $id=$this->session->userdata('user_id');
    if($id==NULL)
    {
        redirect("login_user/user_login_page","refresh");
    }
             $this->load->helper('ckeditor');
        $this->data['ckeditor'] = array(
            //ID of the textarea that will be replaced
            'id' => 'ck_editor',
            'path' => 'scripts/ckeditor',
            'config' => array(
                'toolbar' => "Full", //Using the Full toolbar
                'width' => "500px", //Setting a custom width
                'height' => '300px', //Setting a custom height
            )
        );

} 
    
    public function index()
	{
            $data=array();
              $data['category']=$this->admin_model->get_category();
            $data['main']=$this->load->view('blogpage','',true);
            $data['title']="Blog";
		$this->load->view('home',$data);
	}
      public function logout()
             {
              
              $this->session->unset_userdata('user_id');
              
                 session_destroy();
              redirect("login_user/user_login_page","refresh");
             }
             
             public function profile()
             {
             $this->load->model('user_profile');
             $user_id=$this->session->userdata('user_id');
             $data=array();
             $data['category']=$this->admin_model->get_category();
             $data['result']=$this->user_profile->profile_model($user_id);
            $data['main']=$this->load->view('view_profile',$data,true);
               $data['archives']='true';
              $data['header']="s";
            $data['title']=$this->session->userdata('full_name');
		$this->load->view('home',$data);
                 
             }
             public function edit()
             {
                   $this->load->model('user_profile');
             $user_id=$this->session->userdata('user_id');
             $data=array();
             $data['result']=$this->user_profile->profile_model($user_id);
            $data['main']=$this->load->view('edit_profile',$data,true);
            $data['title']=$this->session->userdata('full_name');
		$this->load->view('home',$data);
             }
             public function update()
             {
                 $data=array();
                 $user_id=  $this->session->userdata('user_id');
                   $data['first_name']=$this->input->post('first_name',true);
            $data['last_name']=$this->input->post('last_name',true);
            $data['email']=$this->input->post('email',true);
            
            $data['address']=$this->input->post('address',true);
            $data['mobile']=$this->input->post('mobile',true);
            $data['city']=$this->input->post('city',true);
            $data['gender']=$this->input->post('gender',true);
            $data['country']=$this->input->post('country',true);
            $data['zip_code']=$this->input->post('zip_code',true);
           
            
            $result=$this->user_profile->user_update($data,$user_id);
            redirect("Blogger/profile");
             }
             public function add_blog()
             {
       
                  $data=array();
                  $data['editor'] = $this->data;
                  $data['header']="s";
                   $data['category']=$this->admin_model->get_category();
            $data['main']=$this->load->view('add_blog',$data,true);
            $data['title']="Add Blog";
            $data['archives']='true';
		$this->load->view('home',$data);
             }
             public function save_post()
             {
                 $data=array();
                 $data['user_id']=$this->session->userdata('user_id');
                 $data['category_id']=$this->input->post('category_id');
                 $data['title']=$this->input->post('title',true);
                 $data['description']=$this->input->post('description',true);
                 $data['status']=$this->input->post('status',true);
                 $data['published_time']=  date('Y-m-d H:m:s');
                $this->blogger_model->add_post($data,$user_id);
                redirect ("Blogger/add_blog"); 
             }
                    public function view_my_blog(){
        
            $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
            $data['result']=$this->blogger_model->show_my_blog($user_id);
            $data['main']=$this->load->view('home_msg',$data,true);
            $data['title']="Blog";
               
              $data['header']="s";
            $data['archives']='true';

		$this->load->view('home',$data);
	}
 
        
                      public function education(){
                          
        $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
             $data['main']=$this->load->view('education',$data,true);
            $data['title']="E-education";
               
              $data['header']="s";
            $data['archives']='true';
            $this->load->view('home',$data);
           
	} 
            

           
	
                              public function year1(){
                          
        $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
             $data['main']=$this->load->view('year1',$data,true);
            $data['title']="E-education";
               
              $data['header']="s";
            $data['archives']='true';
            $this->load->view('home',$data);
           
	}
                              public function year2(){
                          
        $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
             $data['main']=$this->load->view('year2',$data,true);
            $data['title']="E-education";
               
              $data['header']="s";
            $data['archives']='true';
            $this->load->view('home',$data);
           
	}
                              public function year3(){
                          
        $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
             $data['main']=$this->load->view('year3',$data,true);
            $data['title']="E-education";
               
              $data['header']="s";
            $data['archives']='true';
            $this->load->view('home',$data);
           
	}
                              public function year4(){
                          
        $data=array();
            $user_id=$this->session->userdata('user_id');
            $data['category']=$this->admin_model->get_category();
             $data['main']=$this->load->view('year4',$data,true);
            $data['title']="E-education";
               
              $data['header']="s";
            $data['archives']='true';
            $this->load->view('home',$data);
           
	}
       
             
        
               public function save_file(){
       $data = array();
           $data['user_id']=$this->session->userdata('user_id');
        $data['title'] = $this->input->post('title', true);
         $data['course'] = $this->input->post('course');
        
        
        $data['category'] = $this->input->post('category', true);
      
        $data['type'] = $this->input->post('type', true);
        
       $data['file_upload'] = $this->input->post('file_upload', true);
    

        /* -----Start image upload... */
        $config['upload_path'] = './images/file_upload';
        $config['allowed_types'] = 'gif|jpg|pdf|doc|docx|ppt|wav|c';
        $config['max_size'] = '10000';
        $config['max_width'] = '1024';
        $config['max_height'] = '768';
        $error = '';
        $udata = '';
        $this->load->library('upload');
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file_upload')) {
            $error = array('error' => $this->upload->display_errors());
        } else {
            $udata = array('upload_data' => $this->upload->data());
            //echo '<pre>';
            //print_r($udata);
            $data['file_upload'] = "images/file_upload/" . $udata['upload_data']['file_name'];
           $data['file_name'] = $udata['upload_data']['file_name'];
        }
        
         $this->education_model->save_file($data);
        /* -----end image upload... */

           
                                      
             redirect ("Blogger/upload_successful");
        }
           public function upload_successful()
        {
            
              $data=array();
              $data['header']='true';
            //$data['result']=$this->blogger_model->show_blog();
            $data['main']=$this->load->view('upload_successfuly','',true);
           $data['category']=$this->admin_model->get_category();
            $data['title']="Blog";
            $data['archives']='true';

		$this->load->view('home',$data);
        }  
               public function all_downloads(){
        
         $user_id = $this->session->userdata('user_id');
        $data = array();
       
          $data['result'] = $this->blogger_model->select_all_files();
       
        
       
       $data['main'] = $this->load->view('all_downloads', $data, true);
        
            $data['archives']='true';
        $data['title'] = 'Download';
        $data['category']=$this->admin_model->get_category();
        $data['header']="s";
        $this->load->view('home', $data);
    }

    public function full_view($file_id){
          $user_id = $this->session->userdata('user_id');
        $data = array();
         
        $data['result'] = $this->blogger_model->select_file_by_file_id($file_id);

    
        $data['main'] = $this->load->view('full_view', $data, true);
        $data['title'] = 'Full view';
      $data['archives']='true';
      $data['category']=$this->admin_model->get_category();
        $data['header']="s";
        $this->load->view('home', $data);
    }
    
          public function download_file($file_id){
//          echo $file_upload;
//          exit();
           $data = array();
  $data['result'] = $this->blogger_model->select_file_by_file_id($file_id); 

  $name = $data['result']->file_name ;
$data = file_get_contents("./".$data['result']->file_upload.""); // Read the file's contents
 

force_download ($name,$data);  
        
        
    }
        
}

?>
