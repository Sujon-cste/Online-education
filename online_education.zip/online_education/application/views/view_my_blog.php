<?php

echo "<h1>welcome to my Blog</h1>";
//$current_date = Date("Y-m-d\TH:i:s\Z"); 
//echo current_date;
//echo date("d M Y h:i:s ");
echo date('l jS \of F Y h:i:s A');

?>
