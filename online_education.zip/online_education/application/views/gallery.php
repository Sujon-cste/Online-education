<?php

echo "<h1>welcome to my gallery</h1>";
?>
