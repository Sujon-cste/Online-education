 <h2>Hello! Welcome to E_education</h2>

<h2>
    Upload File
</h2>
<h3><?php 
$message=$this->session->userdata('message');
if(isset($message)){
    echo $message;
    $this->session->unset_userdata('message');
}
?></h3><br/>
<form action="<?php echo base_url();?>index.php/Blogger/save_file" method="post" enctype="multipart/form-data"  onsubmit="return validateStandard(this)">
    <table border="1" align="center">
        
       <tr>
            <td>File Title:</td>
            <td><input type="text" name="title"  placeholder="File Title" tabindex="1" required="1" regexp="JSVAL_RX_ALPHA" err="Enter File Title" /><span class="required">*</span></td>
        </tr>
           <tr> 
            <td>Select Course</td>
            <td>
                <select name="course">
                    <option>Select Course......</option>
                    
                     <option value="CSTE-2101">CSTE-2101</option>
                     <option value="CSTE-2102">CSTE-2102</option>
                     <option value="CSTE-2103">CSTE-2103</option>
                     <option value="CSTE-2104">CSTE-2104</option>
                     <option value="CSTE-2105">CSTE-2105</option>
                    <?php
                        foreach($all_course as $v_course)
                        {
                    ?>
                    <option value="<?php echo $v_course->course_id?>"><?php echo $v_course->course_title?></option>
                    <?php } ?>
                </select>
            </td> 
            
        </tr>
        
            
          <tr>
            <td>category:</td>
            <td>
                <input type="radio" name="category" value="project"   />Project<br />
                <input type="radio" name="category" value="assignment"   />Assignment<br />
                <input type="radio" name="category" value="lecture"  />Lecture<br /><br /><br />
            </td>
        </tr>
        <tr>
            <td>File Type:</td>
            <td>
                <input type="radio" name="type" value="pdf"   />Pdf<br />
                <input type="radio" name="type" value="doc"  />Doc/Docx<br />
                <input type="radio" name="type" value="ppt"   />Ppt<br />
                <input type="radio" name="type" value="jpg"   />Jpg<br />
            </td>
        </tr>
        
         <tr>
            <td>Select File</td>
            <td>
                <input type="file" name="file_upload" tabindex="8"/>                
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit" name="btn" tabindex="11" value="Submit"/></td>
        </tr>
    </table>
</form>
<li><a href="<?php echo base_url(); ?>index.php/Blogger/all_downloads" target="_parent">Download</a></li>
