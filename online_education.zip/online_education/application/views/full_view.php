<h2>File Description</h2>
<table border="0" >

    <tr><td> Title : &nbsp;&nbsp;&nbsp;</td>
        <td> <?php echo $result->title; ?></td> </tr><br />
    <tr>
        <td> Category: &nbsp;&nbsp; &nbsp; &nbsp;</td>
        <td>  <p>  <?php echo $result->category ; ?> </p></td>

    </tr>
<tr>
        <td> Course: &nbsp;&nbsp; &nbsp; &nbsp;</td>
        <td>  <p>  <?php echo $result->course; ?> </p></td>

    </tr>

    
   
    




</table>