<?php 
foreach($result as $vresult)
{
?>
<div class="post">
    <h2 class="title"><?php echo $vresult->title?></h2>
    <div class="story">
        <p>
            <?php echo $vresult->description;
             ?>
                 <p  class="file"><a href="<?php echo base_url();?>index.php/welcome/add_comments/<?php echo $vresult->blog_id;?>"><h5>Comments</h5></a>
                   
            </p>
    </div>
    <div class="meta">
        
        <p class="date">Posted <?php echo date('d-m-Y H:i:s'); ?></p>
       
            | <a href="#">Edit</a> | <a href="#">
                Delete</a></p>
    </div>
    <a align="center"></a>
</div>

  <?php

}
?>
</div>