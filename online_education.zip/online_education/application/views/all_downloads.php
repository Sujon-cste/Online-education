<!--<link href="<?php echo base_url() ?>css/download.css" rel="stylesheet" type="text/css" />    -->
<table border="1" align="center" >
    <tr id="th">
        <th>Title</th>
       <th>Course Code</th>
        
         <th>Type</th>
         
          <th>Action</th>
    </tr>
  <?php 
        foreach($result as $vresult)
        {
    ?>          
    <tr id="tr">
        <td id="td"><?php echo $vresult->title;?></td>
         <td id="td"><?php echo $vresult->course;?></td>
         
          
           <td id="td"><?php echo $vresult->type;?></td>
      
        <td id="td">
            <a href="<?php echo base_url();?>index.php/blogger/full_view/<?php echo $vresult->file_id?>" class='button'>View</a> | 
            <a href="<?php echo base_url();?>index.php/Blogger/download_file/<?php echo $vresult->file_id?>" class='button'>Download</a>
        </td>
    </tr>
    <?php } ?>  
</table>