<br/>
<br/>
<?php 
$name=$this->session->userdata('full_name');
?>
<h2>Welcome <?php echo $name; ?> </h2>