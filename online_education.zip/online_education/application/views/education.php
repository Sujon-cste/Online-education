
<li><a href="<?php echo base_url() ?>index.php/blogger/year1">Year 1  </a></li>
<li><a href="<?php echo base_url() ?>index.php/blogger/year2">Year 2  </a></li>
<li><a href="<?php echo base_url() ?>index.php/blogger/year3">Year 3</a></li>
<li><a href="<?php echo base_url() ?>index.php/blogger/year4">Year 4 </a></li>

